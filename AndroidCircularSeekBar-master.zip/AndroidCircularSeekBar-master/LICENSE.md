I've never been a big fan of really large licenses.

Any developer or organisation may use this in their personal, public and commercial projects free of cost. In commercial projects, attribution is required. For personal/public/free to use projects, attribution is optional.
